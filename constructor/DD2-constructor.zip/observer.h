#ifndef _OBSERVER_H_
#define _OBSERVER_H_
#include "info.h"


class Observer {
    public:
    
};

#endif
